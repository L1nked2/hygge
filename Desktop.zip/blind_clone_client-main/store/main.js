// 메인 페이지의 상태
export const state = () => ({});

export const mutations = {};

export const actions = {};
