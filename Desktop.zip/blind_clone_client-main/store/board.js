// 게시판 상태
export const state = () => ({});

export const mutations = {};

export const actions = {};
