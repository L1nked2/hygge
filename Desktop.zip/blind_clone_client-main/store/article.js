// 개별 게시글의 상태
export const state = () => ({});

export const mutations = {};

export const actions = {};
