// 검색 결과의 상태
export const state = () => ({});

export const mutations = {};

export const actions = {};
