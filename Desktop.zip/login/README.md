# Fast campus Online JavaScript Project

[Slide](https://slides.com/woongjae/fc-javascript)

```
npm i
npm start
```
